CREATE TABLE `bird_overrides` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name_key` text NOT NULL,
	`payload` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `bird_overrides_name_key_unique` ON `bird_overrides` (`name_key`);