import { env } from "cloudflare:workers";
import { headers } from "next/headers";
import { NextResponse } from "next/server";

async function authorized() {
  const h = await headers();
  return Boolean(h.get("oai-authenticated-user-id") || h.get("oai-authenticated-user-email"));
}
function key(name:string){return name.normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/\bJUNIOR\b/gi,"JR").replace(/[^A-Z0-9]/gi,"").toUpperCase()}

export async function GET() {
  if(!await authorized()) return NextResponse.json({error:"Não autorizado"},{status:401});
  try{
    const result=await env.DB.prepare("SELECT payload FROM bird_overrides ORDER BY updated_at").all<{payload:string}>();
    return NextResponse.json({birds:result.results.map(row=>JSON.parse(row.payload))});
  }catch(error){console.error("bird_overrides GET",error);return NextResponse.json({birds:[],unavailable:true},{status:503})}
}

export async function PUT(request:Request) {
  if(!await authorized()) return NextResponse.json({error:"Não autorizado"},{status:401});
  const bird=await request.json() as {name?:string};
  if(!bird.name) return NextResponse.json({error:"Nome obrigatório"},{status:400});
  await env.DB.prepare("INSERT INTO bird_overrides (name_key,payload,updated_at) VALUES (?,?,?) ON CONFLICT(name_key) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at").bind(key(bird.name),JSON.stringify(bird),new Date().toISOString()).run();
  return NextResponse.json({ok:true});
}

export async function DELETE(request:Request) {
  if(!await authorized()) return NextResponse.json({error:"Não autorizado"},{status:401});
  const name=new URL(request.url).searchParams.get("name");
  if(!name)return NextResponse.json({error:"Nome obrigatório"},{status:400});
  await env.DB.prepare("DELETE FROM bird_overrides WHERE name_key=?").bind(key(name)).run();
  return NextResponse.json({ok:true});
}
